//
//  YFRecordSetViewController.h
//  YFPlayerPushStreaming-Demo
//
//  Created by apple on 4/11/17.
//  Copyright © 2017 YunFan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFRecordSetViewController : UIViewController

@end
